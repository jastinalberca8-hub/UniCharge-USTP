---
name: USTP UniCharge
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#44474d'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#75777e'
  outline-variant: '#c5c6ce'
  surface-tint: '#515f7a'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#0d1b33'
  on-primary-container: '#7684a1'
  inverse-primary: '#b9c7e6'
  secondary: '#835500'
  on-secondary: '#ffffff'
  secondary-container: '#feae2c'
  on-secondary-container: '#6b4500'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#002113'
  on-tertiary-container: '#009668'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d7e2ff'
  primary-fixed-dim: '#b9c7e6'
  on-primary-fixed: '#0d1b33'
  on-primary-fixed-variant: '#394761'
  secondary-fixed: '#ffddb4'
  secondary-fixed-dim: '#ffb955'
  on-secondary-fixed: '#291800'
  on-secondary-fixed-variant: '#633f00'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.5rem
  gutter-desktop: 2rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system drives the official smart charging locker and kiosk infrastructure across the University of Science and Technology of Southern Philippines (USTP). Tailored for students, faculty, and campus administrators on mobile and kiosk interfaces, it pairs institutional trust with the fast-paced utility of modern IoT power management.

The visual direction combines **Modern Corporate Precision** with **Clean Tactile Utility**. It avoids stale academic bureaucracy by leveraging crisp, elevated card surfaces, high-contrast numeric telemetry, and institutional pride expressed through deep navy tones illuminated by vibrant sunburst gold.

Key emotional targets:
- **Absolute Reliability:** Students must trust that their expensive mobile hardware is secure, powered, and correctly accounted for.
- **Urgent Clarity:** High stress states (e.g., low battery before class, locker release countdowns) demand zero-friction hierarchy, massive glanceable digits, and unmistakable hardware states.
- **Campus Identity:** Elevated native adaptation of USTP's heritage colors tailored for high-performance responsive web and native interfaces.

## Colors

The palette is engineered around high functional contrast, clear state communication, and official institutional heritage.

### Core Swatches
- **Primary (`#0A1931`):** Deep USTP Navy. Anchors top navigation, foundational framing, high-emphasis icons, and structural headings.
- **Secondary (`#F5A623`):** USTP Sunburst Gold. Drives high-priority calls to action, active charging badges, scan triggers, and focal interactive elements.
- **Tertiary (`#10B981`):** Operational Emerald Green. Denotes ready/unlocked status, successful connections, completed charging sessions, and positive balances.
- **Neutral (`#64748B`):** Slate Grey. Governs metadata readouts, secondary labels, borders, and inactive elements.

### Functional Status & Telemetry
- **In-Use / Active Power:** `#F59E0B` (Warning Amber) paired with a 10% soft container fill (`#FEF3C7`).
- **Critical / Locked / Fault:** `#EF4444` (Crimson) paired with an 8% soft fill (`#FEE2E2`).
- **Canvas Base:** `#F8FAFC` (Cool Off-White/Slate 50) accented by crisp `#FFFFFF` card containers and `#F1F5F9` sub-wells.

## Typography

The design system utilizes **Plus Jakarta Sans** uniformly across display, body, and telemetry roles. Its geometric construction delivers rapid legibility in harsh outdoor campus lighting while preserving an approachable, student-friendly personality.

### Typography Rules
- **Telemetry & Locker Numbers:** Slot identifiers (e.g., "BAY 04", "88%") must use `display-lg` with tabular figures (`font-variant-numeric: tabular-nums`) to prevent layout shifts during active charging countdowns.
- **Uppercase Badges:** All chip labels, state tags, and payment badges apply `label-sm` with explicit uppercase casing and expanded letter spacing for quick scanning.
- **Hierarchical Anchors:** Section headers use `headline-md` set in Deep Navy (`#0A1931`) to establish solid architectural grounding over card surfaces.

## Layout & Spacing

The system applies an 8-point base spatial rhythm engineered around compact, thumb-driven mobile workflows and stationary touchscreen kiosks.

### Grid & Breakpoints
- **Mobile (<640px):** 4-column fluid layout with `1rem` margins and `1rem` gutters. Primary action zones are pinned to the bottom thumb-zone (48px to 80px reach).
- **Tablet / Kiosk Terminal (640px - 1024px):** 8-column layout with `2rem` margins. Locker bay grids adopt 2x4 or 3x3 matrices to mirror physical locker geometries.
- **Desktop / Admin Hub (>1024px):** 12-column fixed grid with a max width of 1200px centered on-screen.

### Spacing Distribution
- Use `space-xs` and `space-sm` for internal component anatomy (e.g., icon-to-text spacing, pill internal padding).
- Use `space-md` for standard card padding and form element spacing.
- Use `space-lg` to separate functional groups (e.g., active telemetry readout from payment option selectors).
- Use `space-xl` for sectional transitions and hero kiosk views.

## Elevation & Depth

Visual hierarchy uses **crisp, low-contrast boundary framing paired with soft ambient shadows**, maintaining clarity against sunlight reflections on kiosk glass and smartphone screens.

### Depth Tiers
- **Tier 0 (Canvas):** Flat `#F8FAFC` base surface without elevation.
- **Tier 1 (Surface Cards & Bays):** Background `#FFFFFF` surrounded by a `1px` subtle border in `#E2E8F0` and a diffuse ambient shadow: `0 2px 8px -2px rgba(10, 25, 49, 0.05), 0 1px 4px -1px rgba(10, 25, 49, 0.03)`.
- **Tier 2 (Interactive Floating Bars & Modals):** Background `#FFFFFF` with border `1px` in `#CBD5E1` and an elevated shadow: `0 12px 24px -6px rgba(10, 25, 49, 0.12), 0 4px 8px -2px rgba(10, 25, 49, 0.04)`.
- **Tier 3 (Active Locker Slot Highlight):** Card switches to a `2px` inset outline in `#F5A623` paired with an ambient tinted glow: `0 0 0 3px rgba(245, 166, 35, 0.18)`.

## Shapes

The design system implements a **Rounded (Level 2)** shape aesthetic, reinforcing high-tech equipment usability while keeping elements friendly and ergonomic.

### Corner Radius Standards
- **Small Controls & Tags:** `0.5rem` (`8px`) for status pills, timer capsules, and action chips.
- **Standard Controls & Fields:** `0.75rem` (`12px`) for primary buttons, input fields, and payment method selectors.
- **Structural Cards & Bays:** `1rem` (`16px`) for locker compartment cards, kiosk scan viewfinders, and telemetry panels.
- **Bottom Sheets & Floating Trays:** `1.5rem` (`24px`) top corners for swipe-up transaction drawers.

## Components

### 1. Kiosk Compartment Slot Cards
- **Structure:** Modular container representing physical locker doors. Divided into compartment ID (`display-lg`), pin-lock status indicator, and dynamic availability state.
- **Available State:** `#FFFFFF` background, `#10B981` badge ("READY"), subtle `#E2E8F0` border.
- **Occupied / Charging State:** Pale amber background (`#FFFBEB`), `#F59E0B` border, embedded battery charge trajectory (`%` progress bar with animated pulse).
- **Offline / Error State:** `#F1F5F9` background, muted `#94A3B8` icon, slashed lock symbol.

### 2. QR Scanner Viewfinder
- Viewfinder square with a fixed 1:1 aspect ratio, bounded by `4px` gold bracket corners (`#F5A623`) with a radius of `16px`.
- High-contrast animated sweep line across the scanning plane (`#F5A623` with gradient fade).
- Bottom guidance pill in deep navy (`#0A1931` with 80% opacity) displaying "Align kiosk QR within frame" in white `label-md`.

### 3. Status Telemetry & Countdown Timers
- Numerical readout cards set in `#0A1931` dark surface mode to emphasize mission-critical time metrics.
- Digits formatted in `display-lg` (`40px`, tabular numbers).
- Units ("MIN REMAINING", "AMPS", "WATTS") tagged beneath in uppercase `label-sm` with `#94A3B8` color tint.

### 4. Payment Method Pills
- Selectable pill components for local student payment rails: **GCash**, **Maya**, and **Campus Coin credits**.
- Standard state: `#FFFFFF` fill, `1px` border in `#E2E8F0`, left-aligned monochrome or brand icon, right-aligned balance label.
- Selected state: Deep navy border (`#0A1931`, `2px`), subtle `#EFF6FF` background fill, with a checkmark glyph rendered in Sunburst Gold (`#F5A623`).

### 5. Buttons & Triggers
- **Primary Action (Scan / Unlock):** Background `#F5A623`, text `#0A1931`, weight `700`, height `52px`, pill or `12px` roundedness. Provides high-visibility click/tap affordance.
- **Secondary Action (Cancel / Support):** Background `#F1F5F9`, text `#0A1931`, hover state shifts to `#E2E8F0`.
- **Emergency Release / End Charge:** Outline style with `#EF4444` border and text, activating confirmation dialog on press.